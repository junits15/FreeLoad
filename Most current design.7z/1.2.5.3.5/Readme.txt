At this point features are being added to the freeLoad
- removing 1/2 of fet footprints, 4 FETs are unessecary 
- how voltage limits are generated for pots (no more resistor dividers)
- 4 wire sense
- banana plug hole diameter needs to be shrunk
- switching back to through hole for all componenets 

Future additions:  
Constant ressitance mode  
Battery capacity measurement, with microcontroller control and low voltage cuttoff.   
Coarse and fine adjustment knobs.  
BNC input for current setting.  
High speed load switching to detect power supply output ringing.
150W/15A 